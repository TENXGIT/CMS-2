import { useEffect, useState } from "react";
import axios from "axios";
import Header from "../header/header";
import Item from "../Item/Item";

const Main = ()=>{
    const [videosite, setvideosite] = useState([]);
    const [fangear, setfangear] = useState([]);
    useEffect(()=>{
        axios.get("http://localhost:1337/api/video-site").then((gamedata)=>{
            
                setvideosite(gamedata.data.data)

            }).catch(()=>{

            }).finally(()=>{

            });

            axios.get("http://localhost:1337/api/fan-gear").then((geardata)=>{

                setfangear(geardata.data.data)

            }).catch(()=>{

            }).finally(()=>{

            });

    },[]);
 

    
    return(
        <>
        <Header/>

        <section>
           
           <dt> <b> Video-Game-site </b> </dt>
           {videosite.map((item, key) => {
               return <Item item = {item.attributes} key={key} />
           })}
           

           <dt> <b> Gears </b> </dt>
            {fangear.map((item, key) => {
               return <Item item = {item.attributes} key={key} />
            })}

        </section>
        </>
    )
}

export default Main;