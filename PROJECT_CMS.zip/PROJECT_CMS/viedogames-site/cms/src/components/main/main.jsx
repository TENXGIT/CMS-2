import { useEffect, useState } from "react"
import axios from "axios"
import Header from "../header/header"
import Item from "../item/item"

const Main=()=>{
    const [intrest,setintrest]=useState([])
    const [latest,setlatest]=useState([])
    useEffect(()=>{
        axios.get("http://localhost:1337/api/intrestings").then((intresting)=>{
            setintrest(intresting.data.data)

            }).catch(()=>{

        }).finally(()=>{

        });
        axios.get("http://localhost:1337/api/latests").then((latest)=>{
            setlatest(latest.data.data)

        }).catch(()=>{

    }).finally(()=>{

    })
    },[])
    return(
       <>
       <Header/>
       <section>
        <article>intresting</article>
        {intrest.map((item,key)=>{
          <Item/>
        })}
         <article>latest</article>
        {latest.map((item,key)=>{
            
    
        })}
       </section>
       </> 
    )
}
export default Main