import React from "react"
import "./header.css"
import images from "../images/cart.png"


const Header=()=>{
    return(
       <>
       <nav>
        <section>
          <h1>game-site</h1>
        </section>
              <section>
            {<img src={images} alt="no img found" /> }
        </section> 
       </nav>
       </> 
    )
}
export default Header